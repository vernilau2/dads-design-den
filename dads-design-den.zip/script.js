// ---------- CONFIG (replace placeholders) ----------
const GALLERY_SHEET_PUBLISHED = "PASTE_YOUR_GALLERY_SHEET_URL";
const SHOP_SHEET_PUBLISHED = "PASTE_YOUR_SHOP_SHEET_URL";
const YOUTUBE_CHANNEL_ID = "PASTE_YOUR_CHANNEL_ID";

// ---------- UTILS ----------
document.getElementById('year').textContent = new Date().getFullYear();

// ---------- YouTube latest video (RSS feed, no API key) ----------
function loadLatestYouTube(channelId, iframeIds = ['youtubeFrame','youtubeFrame2']){
  const rss = `https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`;
  fetch(rss).then(r => r.text()).then(txt => {
    const xml = new DOMParser().parseFromString(txt,'application/xml');
    const entry = xml.querySelector('entry link');
    if(!entry) return;
    const videoURL = entry.getAttribute('href');
    const vid = new URL(videoURL).searchParams.get('v');
    iframeIds.forEach(id => {
      const f = document.getElementById(id);
      if(f) f.src = `https://www.youtube.com/embed/${vid}`;
    });
  }).catch(e => console.error('YT load err', e));
}
if(YOUTUBE_CHANNEL_ID !== "PASTE_YOUR_CHANNEL_ID") loadLatestYouTube(YOUTUBE_CHANNEL_ID);

// ---------- Load Gallery from published Google Sheet ----------
function loadGallery(sheetPublishedURL){
  if(!sheetPublishedURL || sheetPublishedURL.includes("PASTE")) return;
  fetch(sheetPublishedURL).then(r => r.text()).then(html => {
    const doc = new DOMParser().parseFromString(html,'text/html');
    const rows = [...doc.querySelectorAll('table tbody tr')];
    const gallery = document.getElementById('gallery');
    gallery.innerHTML = '';
    rows.forEach(tr => {
      const tds = tr.querySelectorAll('td');
      if(tds.length >= 1){
        const imgURL = tds[0].innerText.trim();
        const alt = (tds[1] && tds[1].innerText.trim()) || '';
        const img = document.createElement('img');
        img.src = imgURL;
        img.alt = alt;
        gallery.appendChild(img);
      }
    });
  }).catch(e => console.error('Gallery load err', e));
}
if(GALLERY_SHEET_PUBLISHED && !GALLERY_SHEET_PUBLISHED.includes("PASTE")) loadGallery(GALLERY_SHEET_PUBLISHED);

// ---------- Load Shop from published Google Sheet ----------
function loadShop(sheetPublishedURL){
  if(!sheetPublishedURL || sheetPublishedURL.includes("PASTE")) return;
  fetch(sheetPublishedURL).then(r => r.text()).then(html => {
    const doc = new DOMParser().parseFromString(html,'text/html');
    const rows = [...doc.querySelectorAll('table tbody tr')];
    const list = document.getElementById('shopList');
    list.innerHTML = '';
    rows.forEach(tr => {
      const tds = tr.querySelectorAll('td');
      if(tds.length >= 3){
        const name = tds[0].innerText.trim();
        const url = tds[1].innerText.trim();
        const type = tds[2].innerText.trim().toLowerCase();
        const li = document.createElement('li');
        const left = document.createElement('div');
        left.style.flex = '1';
        left.innerHTML = `<strong>${name}</strong><div class="muted" style="font-size:13px">${type}</div>`;
        const action = document.createElement('div');
        if(type === 'affiliate'){
          action.innerHTML = `<a href="${url}" target="_blank" class="btn">Buy (Affiliate)</a>`;
        } else if(type === 'digital'){
          action.innerHTML = `<a href="${url}" target="_blank" class="btn">Buy (Digital)</a>`;
        } else if(type === 'dropship_manual'){
          action.innerHTML = `<a href="${url}" target="_blank" class="btn ghost">Supplier</a><span style="margin-left:8px;font-size:12px;color:#999">Manual order</span>`;
        } else if(type === 'pod'){
          action.innerHTML = `<a href="${url}" target="_blank" class="btn">Print-on-Demand</a>`;
        } else {
          action.innerHTML = `<a href="${url||'#'}" target="_blank" class="btn">View</a>`;
        }
        li.appendChild(left);
        li.appendChild(action);
        li.style.display = 'flex';
        li.style.alignItems = 'center';
        list.appendChild(li);
      }
    });
  }).catch(e => console.error('Shop load err', e));
}
if(SHOP_SHEET_PUBLISHED && !SHOP_SHEET_PUBLISHED.includes("PASTE")) loadShop(SHOP_SHEET_PUBLISHED);
